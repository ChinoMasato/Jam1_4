#include "Graph.h"
#include "DxLib.h"

int lightpht;
int TitleLogo;
int Gameoverpht;
int PushEnterKey;

void initGraph()
{
	lightpht = LoadGraph("A_light.png");
	Gameoverpht = LoadGraph("gazou.mati");
	TitleLogo = LoadGraph("youjosenki (1).png");
	PushEnterKey = LoadGraph("i");
}
void updateGraph()
{

}
void drawGraph()
{

}