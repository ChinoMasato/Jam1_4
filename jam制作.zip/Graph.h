#pragma once
extern int TitleLogo;
extern int lightpht;
extern int Gameoverpht;
void initGraph();
void updateGraph();
void drawGraph();
