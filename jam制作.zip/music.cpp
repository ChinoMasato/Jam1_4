#include "DxLib.h"
#include "music.h"