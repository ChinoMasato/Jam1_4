#pragma once
#include"player.h"
#include"enemy.h"
void drawUI();
void drawEHp(En en1);